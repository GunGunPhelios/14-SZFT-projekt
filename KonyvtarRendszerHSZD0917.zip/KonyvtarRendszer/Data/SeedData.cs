﻿using KonyvtarRendszer.Models;
using LibraryApi.Data;
using System;

namespace KonyvtarRendszer.Data
{
    public static class SeedData
    {
        public static void Initialize(LibraryDbContext context)
        {
            if (!context.Books.Any())
            {
                context.Books.AddRange(
                    new Book { Title = "1984", Author = "George Orwell", ISBN = "1234567890123", PublishYear = 1949, Genre = "Dystopian", CreatedAt = DateTime.Now },
                    new Book { Title = "The Hobbit", Author = "J.R.R. Tolkien", ISBN = "1234567890124", PublishYear = 1937, Genre = "Fantasy", CreatedAt = DateTime.Now }
                );
            }

            if (!context.Members.Any())
            {
                context.Members.AddRange(
                    new Member { Name = "John Doe", Email = "john@example.com", PhoneNumber = "123456789", RegistrationDate = DateTime.Now },
                    new Member { Name = "Jane Smith", Email = "jane@example.com", PhoneNumber = "987654321", RegistrationDate = DateTime.Now }
                );
            }

            context.SaveChanges();
        }
    }
}

