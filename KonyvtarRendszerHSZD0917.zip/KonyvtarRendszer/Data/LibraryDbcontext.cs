﻿using KonyvtarRendszer.Models;
using Microsoft.EntityFrameworkCore;

namespace LibraryApi.Data // 🔥 NE az legyen, hogy namespace LibraryDbContext
{
    public class LibraryDbContext : DbContext
    {
        public LibraryDbContext(DbContextOptions<LibraryDbContext> options) : base(options) { }

        public DbSet<Book> Books { get; set; }
        public DbSet<Member> Members { get; set; }
        public DbSet<Borrowing> Borrowings { get; set; }
        

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Book konfiguráció
            modelBuilder.Entity<Book>(entity =>
            {
                entity.ToTable("Books");

                entity.HasKey(b => b.Id);

                entity.HasIndex(b => b.ISBN).IsUnique();

                entity.Property(b => b.Title)
                    .IsRequired()
                    .HasMaxLength(200);

                entity.Property(b => b.Author)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(b => b.ISBN)
                    .HasMaxLength(13);

                entity.Property(b => b.Genre)
                    .HasMaxLength(50);

                entity.Property(b => b.IsAvailable)
                    .HasDefaultValue(true);
            });

            // Member konfiguráció
            modelBuilder.Entity<Member>(entity =>
            {
                entity.ToTable("Members");

                entity.HasKey(m => m.Id);

                entity.HasIndex(m => m.Email).IsUnique();

                entity.Property(m => m.Name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(m => m.PhoneNumber)
                    .HasMaxLength(15);

                entity.Property(m => m.IsActive)
                    .HasDefaultValue(true);
            });

            // Borrowing konfiguráció
            modelBuilder.Entity<Borrowing>(entity =>
            {
                entity.ToTable("Borrowings");

                entity.HasKey(b => b.Id);

                entity.HasOne(b => b.Book)
                    .WithMany()
                    .HasForeignKey(b => b.BookId)
                    .OnDelete(DeleteBehavior.Cascade);

                entity.HasOne(b => b.Member)
                    .WithMany()
                    .HasForeignKey(b => b.MemberId)
                    .OnDelete(DeleteBehavior.Cascade);
            });
        }
    }
}
