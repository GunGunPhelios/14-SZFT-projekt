﻿using KonyvtarRendszer.DTOs;
using KonyvtarRendszer.Models;
using LibraryApi.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace KonyvtarRendszer.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BorrowingsController : ControllerBase
    {
        private readonly LibraryDbContext _context;

        public BorrowingsController(LibraryDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<BorrowingDto>>> GetAll()
        {
            return await _context.Borrowings
                .Include(b => b.Book)
                .Include(b => b.Member)
                .Select(b => new BorrowingDto
                {
                    Id = b.Id,
                    BookTitle = b.Book.Title,
                    MemberName = b.Member.Name,
                    BorrowDate = b.BorrowDate,
                    ReturnDate = b.ReturnDate,
                    DueDate = b.DueDate
                }).ToListAsync();
        }

        [HttpPost]
        public async Task<IActionResult> Create(int bookId, int memberId)
        {
            var book = await _context.Books.FindAsync(bookId);
            if (book == null || !book.IsAvailable)
                return BadRequest("Book not available");

            var member = await _context.Members.FindAsync(memberId);
            if (member == null)
                return BadRequest("Member not found");

            var borrowing = new Borrowing
            {
                BookId = bookId,
                MemberId = memberId,
                BorrowDate = DateTime.Now,
                DueDate = DateTime.Now.AddDays(14)
            };

            book.IsAvailable = false;
            _context.Borrowings.Add(borrowing);
            await _context.SaveChangesAsync();

            return Ok();
        }

        [HttpPut("{id}/return")]
        public async Task<IActionResult> Return(int id)
        {
            var borrowing = await _context.Borrowings
                .Include(b => b.Book)
                .FirstOrDefaultAsync(b => b.Id == id);

            if (borrowing == null || borrowing.ReturnDate != null)
                return BadRequest("Invalid borrowing");

            borrowing.ReturnDate = DateTime.Now;
            borrowing.Book.IsAvailable = true;

            await _context.SaveChangesAsync();
            return Ok();
        }
    }
}
