﻿using System.ComponentModel.DataAnnotations;

namespace KonyvtarRendszer.DTOs
{
    public class CreateBookDto
    {
        
            [Required, MaxLength(200)]
            public string Title { get; set; }

            [Required, MaxLength(100)]
            public string Author { get; set; }

            [Required, StringLength(13)]
            public string ISBN { get; set; }

            public int PublishYear { get; set; }

            [MaxLength(50)]
            public string Genre { get; set; }
        }

    }

