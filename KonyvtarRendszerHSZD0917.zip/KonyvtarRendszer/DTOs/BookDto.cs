﻿namespace KonyvtarRendszer.DTOs
{
    public class BookDto : CreateBookDto
    {
        public int Id { get; set; }
        public bool IsAvailable { get; set; }
    }
}

