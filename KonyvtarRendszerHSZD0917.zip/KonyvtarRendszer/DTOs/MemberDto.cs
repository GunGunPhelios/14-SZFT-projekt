﻿namespace KonyvtarRendszer.DTOs
{
    public class MemberDto : CreateMemberDto
    {
        public int Id { get; set; }
        public DateTime RegistrationDate { get; set; }
        public bool IsActive { get; set; }
    }
}
