﻿using HSZD_Dolgozat.Models;
using Microsoft.EntityFrameworkCore;

namespace HSZD_Dolgozat.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }


        public DbSet<User> Users { get; set; }     // Ha a User modellt választod
    }
}
