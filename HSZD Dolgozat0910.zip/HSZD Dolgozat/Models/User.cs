﻿namespace HSZD_Dolgozat.Models
{
    public class User
    {
    
            public int Id { get; set; }                // Egyedi azonosító
            public string Username { get; set; }       // Felhasználónév
            public string Email { get; set; }          // Email cím
            public string PasswordHash { get; set; }   // Titkosított jelszó
            public string? FullName { get; set; }      // Teljes név (opcionális)
            public DateTime CreatedAt { get; set; } = DateTime.Now;
            public bool IsActive { get; set; } = true;
        }
    }
