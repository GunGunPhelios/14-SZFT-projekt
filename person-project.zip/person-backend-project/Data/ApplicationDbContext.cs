﻿using Microsoft.EntityFrameworkCore;
using WebApplication1.Model;

namespace WebApplication1.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options) { }

        // DbSet a Person entitásnak
        public DbSet<Person> People { get; set; }

        // Seed adatok hozzáadása
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Seed adatok a Person entitáshoz
            modelBuilder.Entity<Person>().HasData(
                new Person
                {
                    Id = 1,
                    FirstName = "John",
                    LastName = "Doe",
                    Age = 30,
                    DateOfBirth = new DateTime(1993, 5, 15),
                    Email = "john.doe@example.com",
                    Address = "123 Main St, Springfield",
                    PhoneNumber = "+1234567890"
                },
                new Person
                {
                    Id = 2,
                    FirstName = "Jane",
                    LastName = "Smith",
                    Age = 28,
                    DateOfBirth = new DateTime(1995, 7, 20),
                    Email = "jane.smith@example.com",
                    Address = "456 Elm St, Springfield",
                    PhoneNumber = "+1987654321"
                },
                new Person
                {
                    Id = 3,
                    FirstName = "Robert",
                    LastName = "Johnson",
                    Age = 35,
                    DateOfBirth = new DateTime(1988, 12, 5),
                    Email = "robert.johnson@example.com",
                    Address = "789 Oak St, Springfield",
                    PhoneNumber = "+1122334455"
                }
            );
        }
    }
}