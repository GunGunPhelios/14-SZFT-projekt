﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Model
{
    public class Person
    {
        [Key]
        public int Id { get; set; } // Az egyedi azonosító, amely az adatbázisban Primary Key lesz

        [Required]
        [StringLength(100, ErrorMessage = "The name cannot be longer than 100 characters.")]
        public string FirstName { get; set; } // Keresztnév

        [Required]
        [StringLength(100, ErrorMessage = "The surname cannot be longer than 100 characters.")]
        public string LastName { get; set; } // Vezetéknév

        [Range(0, 120, ErrorMessage = "Age must be between 0 and 120.")]
        public int Age { get; set; } // Életkor

        [DataType(DataType.Date)]
        public DateTime DateOfBirth { get; set; } // Születési dátum

        [Required]
        [EmailAddress]
        [StringLength(200, ErrorMessage = "The email cannot be longer than 200 characters.")]
        public string Email { get; set; } // Email cím

        [StringLength(300, ErrorMessage = "The address cannot be longer than 300 characters.")]
        public string Address { get; set; } // Cím (opcionális)

        [Phone]
        [StringLength(15, ErrorMessage = "The phone number cannot be longer than 15 characters.")]
        public string PhoneNumber { get; set; } // Telefonszám (opcionális)

        public string FullName => $"{LastName} {FirstName}"; // Kiszámolt tulajdonság: teljes név
    }
}
