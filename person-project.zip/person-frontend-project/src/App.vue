<template>
  <div id="app">
    <h1>Persons List</h1>
    <!-- Ha van adat, akkor megjelenítjük -->
    <div v-if="persons.length">
      <ul>
        <li v-for="person in persons" :key="person.id">
          <p><strong>Full Name:</strong> {{ person.fullName }}</p>
          <p><strong>First Name:</strong> {{ person.firstName }}</p>
          <p><strong>Last Name:</strong> {{ person.lastName }}</p>
          <p><strong>Age:</strong> {{ person.age }}</p>
          <p><strong>Email:</strong> {{ person.email }}</p>
          <p><strong>Phone Number:</strong> {{ person.phoneNumber }}</p>
        </li>
      </ul>
    </div>

    <!-- Ha még nincsenek adatok, akkor betöltés állapot -->
    <div v-else>
      <p>Loading...</p>
    </div>
  </div>
</template>

<script lang="ts">
import { ref, onMounted } from 'vue';
import { getPersons, type Person } from './api';

export default {
  setup() {
    // Ref a személyek adatainak tárolására
    const persons = ref<Person[]>([]);
    const loading = ref<boolean>(true);

    // API hívás az adatok lekérésére
    const fetchPersons = async () => {
      try {
        const response = await getPersons();
        persons.value = response.data;
      } catch (error) {
        console.error("Error fetching persons:", error);
      } finally {
        loading.value = false;
      }
    };

    // Komponens betöltődésekor meghívjuk a fetchPersons függvényt
    onMounted(fetchPersons);

    return { persons, loading };
  }
};
</script>

<style>

</style>
