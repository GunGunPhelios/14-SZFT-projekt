import axios from 'axios';

// Alap API URL
const API_URL = 'https://localhost:7175/api/Person';

// Definiáljuk a személy típusát
export interface Person {
  id: number;
  firstName: string;
  lastName: string;
  age: number;
  dateOfBirth: string;
  email: string;
  address: string;
  phoneNumber: string;
  fullName: string;
}

// AxiosResponse típus importálása típus-only módon
import type { AxiosResponse } from 'axios';

// GET - Lekérdezi az összes személy adatát
export const getPersons = (): Promise<AxiosResponse<Person[]>> => {
  return axios.get(API_URL);
};

// POST - Új személy hozzáadása
export const addPerson = (person: Person): Promise<AxiosResponse<Person>> => {
  return axios.post(API_URL, person);
};

// GET - Lekérdezi egy személy adatát az ID alapján
export const getPersonById = (id: number): Promise<AxiosResponse<Person>> => {
  return axios.get(`${API_URL}/${id}`);
};

// DELETE - Törli a személyt az ID alapján
export const deletePerson = (id: number): Promise<AxiosResponse> => {
  return axios.delete(`${API_URL}/${id}`);
};
